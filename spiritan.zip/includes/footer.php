<footer>
  <div class="container-fluid" id="footer_social">
    <div class="container">
      <div class="row center-blocks">
        <div class="col-sm-1 center-blocks pull-right">
          <a href="#"><img src="img/facebook_social.png" alt="Facebook" class="center-blocks img-responsive"></a>
        </div>
        <div class="col-sm-1 center-blocks pull-right">
          <a href="#"><img src="img/twitter_social.png" alt="Twitter" class="center-blocks img-responsive"></a>
        </div> 
        <div class="col-sm-1 center-blocks pull-right">
          <a href="#"><img src="img/blog_social.png" alt="Blog" class="center-blocks img-responsive"></a>
        </div> 
        <div class="col-sm-1 center-blocks">
          <a href="#"><img src="img/instagram_social.png" alt="Instagram" class="center-blocks img-responsive"></a>
        </div>
        <div class="col-sm-1 center-blocks">
          <a href="#"><img src="img/linkedin_social.png" alt="LinkedIn" class="center-blocks img-responsive"></a>
        </div> 
        <div class="col-sm-1 center-blocks">
          <a href="#"><img src="img/google_social.png" alt="Google plus" class="center-blocks img-responsive"></a>
        </div>    
      </div>
      
    </div>

  </div>

  <div class="container-fluid footer_down">
      <div class="container">
        <div class="row">
          <div class="col-sm-3">
            <caption>
              <h4>RESOURCES</h4>
            </caption>
            <ul>
              <li>E-library</li>
              <li>Partner Universities</li>
              <li>Spiritan Uni Updates</li>
              <li>Spiritan Uni Conferences</li>
              <li>Innaugural lectures</li>
              <li>Housing</li>
              <li>Fees update</li>
            </ul>

          </div>
          <div class="col-sm-3">
            <caption>
              <h4>PRINTS</h4>
            </caption>
            <ul>
              <li>Publications</li>
              <li>International</li>
              <li>News and Events</li>
              <li>About Spiritan Uni</li>
            </ul>
          </div>
          <div class="col-sm-3">
            <caption>
              <h4>QUICK LINKS</h4>
            </caption>
            <ul>
              <li>Maps and Directions</li>
              <li>Search Spiriran</li>
              <li>Terms of Use</li>
              <li>Other Info</li>
            </ul>
          </div>
          <div class="col-sm-3">
            <caption>
              <h4>SPIRITAN UNIVERSITY</h4>
            </caption>
            <p>
              New Chime Estate<br>
              Owerri, Imo State.
              P.M.B 101010.
            </p>
            <p>
              Website: www.spiritanuni.edu.ng<br>
              Email: contact@spiritanuni.edu.ng<br>
              &copy; 2016 Spiritan University. All rights reserved.
            </p>
          </div>
      </div>    
    </div>
    <div class="container-fluid footer_line">
      <div class="container">
        <div class="row">
          <div class="col-sm-12 footer">
          <div class="col-sm-4">
            &copy; 2016 Spiritan University. All rights reserved.
          </div>
          <div class="col-sm-8 text-right">
            <a href="#">Powered by: ICTC, SPIRITAN</a>
          </div>
      </div>
        </div>
      </div>
      </div>
    </div>

     
    </footer>